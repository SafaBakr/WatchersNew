import 'package:flutter/material.dart';

class ContributePage extends StatefulWidget {
  ContributePage({Key? key}) : super(key: key);

  @override
  _ContributePageState createState() => _ContributePageState();
}

class _ContributePageState extends State<ContributePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Text('Comming Soon....'),
      ),
    );
  }
}
