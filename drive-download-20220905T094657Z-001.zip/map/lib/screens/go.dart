import 'package:flutter/material.dart';

class GoPage extends StatefulWidget {
  GoPage({Key? key}) : super(key: key);

  @override
  _GoPageState createState() => _GoPageState();
}

class _GoPageState extends State<GoPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Text('Comming Soon....'),
      ),
    );
  }
}
