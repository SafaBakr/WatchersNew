import 'package:flutter/material.dart';

class UpdatesPage extends StatefulWidget {
  UpdatesPage({Key? key}) : super(key: key);

  @override
  _UpdatesPageState createState() => _UpdatesPageState();
}

class _UpdatesPageState extends State<UpdatesPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Text('Comming Soon....'),
      ),
    );
  }
}
